@extends('layouts.main')

@section('container')
  <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>
@endsection