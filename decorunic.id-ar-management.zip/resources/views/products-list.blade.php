@extends('layouts.main')

@section('container')
  <h1 class="h3 mb-4 text-gray-800">Product List</h1>
@endsection