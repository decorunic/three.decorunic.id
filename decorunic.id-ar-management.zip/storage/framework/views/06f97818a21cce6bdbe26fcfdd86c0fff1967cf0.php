

<?php $__env->startSection('container'); ?>
  <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding Workspace\decorunic.id-ar-management\resources\views/dashboard.blade.php ENDPATH**/ ?>